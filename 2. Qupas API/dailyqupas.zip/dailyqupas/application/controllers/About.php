<?php 


class about extends CI_Controller{

	public function index()
	{
		$data['judul'] = 'About | Daily Qupas';
		$this->load->view('public/header', $data);
		$this->load->view('public/about');
		$this->load->view('public/footer');
	}
	public function api()
	{
		$data['judul'] = 'Public API | Daily Qupas';
		$this->load->view('public/header', $data);
		$this->load->view('public/api');
		$this->load->view('public/footer');
	}
}


 ?>