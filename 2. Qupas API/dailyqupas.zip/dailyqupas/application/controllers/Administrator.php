<?php 


class Administrator extends CI_Controller{

	function __construct(){
		parent::__construct();
		$this->load->model('qupas_model');
	}

	public function index()
	{
		$data['judul'] = 'Administrator Daily Qupas'; 
		$this->load->view('admin/header', $data);
		$this->load->view('admin/index');
		$this->load->view('admin/footer');

	}
	public function post_daily()
	{
		$data['judul'] = 'POST DAILY QUPAS'; 
		$data['kategori'] = $this->qupas_model->getData('category');
		$this->load->view('admin/header', $data);
		$this->load->view('admin/post', $data);
		$this->load->view('admin/footer');
	}
	public function list_daily()
	{
		$data['judul'] = 'LIST DAILY QUPAS';
		$data['list'] = $this->qupas_model->getData('db'); 
		$this->load->view('admin/header', $data);
		$this->load->view('admin/list');
		$this->load->view('admin/footer');
	}
	public function create()
	{
		$this->qupas_model->posting();

		redirect(base_url('administrator/list_daily'));
	}
	public function kategori()
	{
		$data['judul'] = 'Kategori | Qupas Daily';
		$this->load->view('admin/header' , $data);
		$this->load->view('admin/kategori');
		$this->load->view('admin/footer');
	}
	public function create_kategori()
	{
		$m = $this->qupas_model->kategori();

		redirect(base_url('administrator/kategori'));	
	}
	public function hapus_post_daily($id)
	{
		$this->qupas_model->hapus_post($id,'db');

		redirect(base_url('administrator/list_daily'));	
	}

	public function list_kategori()
	{
		$data['judul'] = 'List Kategori | Qupas Daily Administrator';
		$data['kategori']  = $this->qupas_model->getData('category');
		$this->load->view('admin/header', $data);
		$this->load->view('admin/list_kategori' , $data);
		$this->load->view('admin/footer');

	}

	public function hapus_kategori($id)
	{
		$this->qupas_model->hapus_post($id,'category');

		redirect(base_url('administrator/list_kategori'));	
	}
	public function edit_kategori($id)
	{
		$data['kategori'] = $this->qupas_model->getDataBy('category',$id);
		$data['judul'] = 'Category | Qupas Daily Administrator';

		
		$this->load->view('admin/header',$data);
		$this->load->view('admin/edit', $data);
		$this->load->view('admin/footer');
	}
	public function edit_kategori_qupas($id)
	{
		$this->qupas_model->edit($id);

		redirect(base_url('administrator/list_kategori'));
	}

}


 ?>