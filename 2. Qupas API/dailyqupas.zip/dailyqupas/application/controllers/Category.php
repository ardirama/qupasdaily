<?php 

class category extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('qupas_model');
	}
	public function index()
	{	
		$data['judul'] = 'Home | Daily Qupas';
		$data['kategori'] = $this->qupas_model->getData('category');
		$data['isi'] = $this->qupas_model->getData('db');
		$this->load->view('public/header', $data);
		$this->load->view('public/index', $data);
		$this->load->view('public/footer');
	}

	public function tags()
	{
		$data['judul'] = 'Category | Daily Qupas';
		$data['tags'] = $this->qupas_model->getData('category');
		$this->load->view('public/header', $data);
		$this->load->view('public/tags', $data);
		$this->load->view('public/footer');
	}
	
	public function detail($kategori)
	{
		$data['judul'] = 'Detail Category | Daily Qupas';
		$data['kategori_m'] = $this->qupas_model->detail_m($kategori);
		$data['kategori'] = $kategori;
		$this->load->view('public/header', $data);
		$this->load->view('public/detail', $data);
		$this->load->view('public/footer');
	}
	public function content($id)
	{
		$data['content'] = $this->qupas_model->content($id);
		$data['kategori'] = $this->qupas_model->getData('category');
		$data['judul'] = $data['content'][0]['judul'];
		$this->load->view('public/header', $data);
		$this->load->view('public/content', $data);
		$this->load->view('public/footer');
	}

}


 ?>