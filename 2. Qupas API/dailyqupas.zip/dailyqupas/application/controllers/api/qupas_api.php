<?php 	
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;


class qupas_api extends REST_Controller {

		public function __construct()
		{
			parent::__construct();
			$this->load->model('qupas_model');
		}

		public function index_get()
		{
			$id = $this->get('judul');
			if ($id == null) {
				$api = $this->qupas_model->getApi();	
			}else{
				$api = $this->qupas_model->getApi($id);
			}
			
			if ($api) {
				$this->response([
                    'status' => true,
                    'data' => $api
                ], REST_Controller::HTTP_OK);
			}else{
				$this->response([
                    'status' => false,
                    'message' => 'judul not found!' 
                ], REST_Controller::HTTP_NOT_FOUND);
			}
			
		}

		public function index_delete()
		{
			$id = $this->delete('id');

			$p = $this->qupas_model->deleteApi($id);

			if ($p) {
				$this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'success deleted!' 
                ], REST_Controller::HTTP_OK);	
			}else{
				$this->response([
                    'status' => false,
                    'message' => 'Gagal Di Delete!'
                ], REST_Controller::HTTP_BAD_REQUEST);	
			}

		}

		public function index_put()
		{
			$id = $this->put('id');
			$judul = $this->put('judul');
			$tag = $this->put('tag');
			$content = $this->put('content');
			$data = [
			'id' => $id,
			'judul' => $judul,
			'date' => date('Y m d h:i'),
			'tag' => $tag,
			'content' => $content
		];
			$up = $this->qupas_model->update($id,$data);

			if ($up) {
				$this->response([
                    'status' => true,
                    'data' => $data,
                    'message' => 'Updated Success!'
                ], REST_Controller::HTTP_OK);	
			}else{
				$this->response([
                    'status' => false,
                    'message' => 'Updated Success!'
                ], REST_Controller::HTTP_BAD_REQUEST);	
			}

		}

		public function index_post()
		{
			$data = [
				'id' => '',
				'judul' => $this->post('judul'),
				'date' => date('Y m d h:i'),
				'tag' => $this->post('tag'),
				'content' => $this->post('content')
			];

			$create = $this->qupas_model->create($data);

			if ($create) {
				$this->response([
                    'status' => true,
                    'message' => 'Data has Created!'
                ], REST_Controller::HTTP_OK);		
			}else{
				$this->response([
                    'status' => false,
                    'message' => 'Data Not Has Created!'
                ], REST_Controller::HTTP_BAD_REQUEST);		
			}
		}



}