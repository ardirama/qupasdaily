<?php 

class qupas_model extends CI_Model{

	public function posting()
	{
		$judul = $this->input->post('judul');
		$tag = $this->input->post('tag');
		$content = $this->input->post('content');
		$gbr = $_FILES['gbr'];
		if ($gbr = '') {
		}else{
			$config['upload_path'] = './gambar/';
			$config['allowed_types'] = 'jpg|png|jpeg';

			$this->load->library('upload', $config);
			if (!$this->upload->do_upload('gbr')) {
				echo "gagal"; die;
			}else{
				$gbr = $this->upload->data('file_name');
			}
		}

		$data = [
			'id' => null,
			'judul' => $judul,
			'gambar' => $gbr,
			'date' => date('d m Y h:i'),
			'tag' => $tag,
			'content' => $content
		];
		return $this->db->insert('db', $data);
	}

	public function kategori()
	{
		$kategori = $this->input->post('kategori');
		$gbr = $_FILES['gbr'];
		if ($gbr = '') {
		}else{
			$config['upload_path'] = './gambar/';
			$config['allowed_types'] = 'jpg|png|jpeg';

			$this->load->library('upload', $config);
			if (!$this->upload->do_upload('gbr')) {
				echo "gagal"; die;
			}else{
				$gbr = $this->upload->data('file_name');
			}
		}
		$k = [
			'id' => null,
			'kategori' => $kategori,
			'gambar' => $gbr
		];
		return $this->db->insert('category', $k);
	}

	public function getData($q, $id = null)
	{	
		$this->db->order_by('id', 'DESC');
		$c = $this->db->get($q)->result();
		return $c;

	}
	public function hapus_post($id,$db)
	{
		$this->db->where('id', $id);
		return $this->db->delete($db);
	}

	public function getApi($id=null)
	{
		if ($id == null) {
			return $this->db->get('db')->result_array();
		}else{
			return $this->db->get_where('db', ['judul' => $id])->result_array();
		}

	}

	public function deleteApi($id)
	{
		$this->db->where('id' , $id);
		return $this->db->delete('db');
	}

	public function update($id,$data)
	{
		$this->db->where('id', $id);
		return $this->db->update('db' , $data);
	}

	public function create($data)
	{
		return $this->db->insert('db', $data);
	}

	public function detail_m($kategori)
	{
		$this->db->where('tag', $kategori);
		return $this->db->get('db')->result();
	}
	public function content($id){
		$this->db->where('id', $id);
		return $this->db->get('db')->result_array();
	}

	public function edit($id)
	{
		$kategori = $this->input->post('nama');
		$gbr = $_FILES['gbr'];
		if ($gbr = '') {
		}else{
			$config['upload_path'] = './gambar/';
			$config['allowed_types'] = 'jpg|png|jpeg';

			$this->load->library('upload', $config);
			if (!$this->upload->do_upload('gbr')) {
				echo "gagal"; die;
			}else{
				$gbr = $this->upload->data('file_name');
			}
		}


		$db = [
			'id' => '',
			'kategori' => $kategori,
			'gambar' => $gbr
		]; 
		$this->db->where('id', $id);
		return $this->db->update('category', $db);
	}

	public function getDataBy($db,$id)
	{

		$this->db->where('id', $id);
		return $this->db->get($db)->result_array();
	}


}


 ?>