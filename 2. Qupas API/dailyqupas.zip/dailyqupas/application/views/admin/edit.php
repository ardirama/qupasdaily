<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        POSTING DAILY
      </h1>
      <ol class="breadcrumb">
        <li><a href="index"><i class="fa fa-dashboard"></i>administrator</a></li>
        <li class="active">Post_daily</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">

      <!--------------------------
        | Your Page Content Here |
        -------------------------->
        <div class="row justify-content-center">
          <div class="col-md-2"></div>
          <div class="col-md-7">
            <h4 class="text-center"><b>QUpas DAily</b> CMS</h4>
            <form method="post" enctype="multipart/form-data" action="<?= base_url('administrator/edit_kategori_qupas/'. $kategori[0]['id']) ?>"> 
              <div class="form-group">
                <h2><small>Category :</small></h2>
                <input type="text" name="nama" class="form-control" value="<?= $kategori[0]['kategori'] ?>">
              </div>
              <div class="form-group">
                <h2><small>Gambar :</small></h2>
                <input type="file" name="gbr" class="form-control">
              </div>
              <div class="form-group text-right">
                <button class="btn btn-primary">SUBMIT</button>
              </div>
            </form>
          </div>
        </div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

 