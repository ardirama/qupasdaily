    <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Create Kategori  
      </h1>
      <ol class="breadcrumb">
        <li><a href="index"><i class="fa fa-dashboard"></i>administrator</a></li>
        <li class="active">kategori</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">

      <!--------------------------
        | Your Page Content Here |
        -------------------------->

        <div class="row">
          <div class="col-md-3"></div>
          <div class="col-md-6 ">
            <?php echo form_open_multipart(base_url('administrator/create_kategori')); ?>
              <div class="form-group">
                <label>Tambah Kategori :</label>
                <input type="text" name="kategori" class="form-control" placeholder="example : Makanan Atau Lainnya">
                <p class="text-danger"><b>*</b>Catatan : Tidak Boleh Membuat Lebih dari 1 Kategori!</p>
              </div>
              <div class="form-group">
                <label>Upload Gambar :</label> 
                <input type="file" name="gbr" class="form-control">
                <p class="text-danger"><b>*</b>Catatan : Gambar Harus Menyesuaikan Dengan Kategori!</p>
              </div>
              <div class="form-group float-right"> 
                <button class="btn btn-primary">Submit</button>
              </div>
            <?php echo form_close(); ?>
          </div>
        </div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

 