    <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        List Qupas Daily
      </h1>
      <ol class="breadcrumb">
        <li><a href="index"><i class="fa fa-dashboard"></i>administrator</a></li>
        <li class="active">List_daily</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">

      <!--------------------------
        | Your Page Content Here |
        -------------------------->

        <div class="row">
          <div class="col-md-1"></div>
          <div class="col-md-10">
            <a href="<?= base_url() ?>administrator/kategori" class="btn btn-primary"><i class="fa fa-plus"></i> New Kategori</a>
           <div class="table-responsive">  
            <table class="table table-hover table-striped table-bordered">
              <thead>
                <tr>
                  <th>NO</th>
                  <th>TAG / CATEGORY</th>
                  <th>Gambar</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $no = 1;
                 foreach ($kategori as $key) {?>
                <tr>
                  <td><?= $no++ ?></td>
                  <td><?= $key->kategori ?></td>
                  <td><img class="img-fluid" width="200px" src="<?= base_url('gambar/'.$key->gambar) ?>"></td>
                  <td><a href="<?= base_url('administrator/hapus_kategori/'.$key->id) ?>" class="btn btn-danger btn-sm">Hapus</a> <a href="<?= base_url('administrator/edit_kategori/'.$key->id) ?>" class="btn btn-primary btn-sm">Edit</a></td>
                </tr>
              <?php   } ?>
              </tbody>
            </table>
          </div> 
        </div>
      </div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

 