<div class="container mt-5">
	<div class="row">
		<div class="col-md-3"></div>
		<div class="col-md-6">
			<div class="text-center">
				<img src="https://www.qupas.id/assets/layout/images/app-name.png" class="img-fluid">
			</div>
			<section id="" class="mt-4">
				<p><b>Qupas</b> is an Information Technology Startup that produces products in the form of review applications and News based on Mobile Android & iOS. Qupas was established in Sidoarjo, Indonesia in 2018. Qupas is currently used in major cities in Indonesia such as Surabaya, Bali, and will continue to grow in other cities in Indonesia.

				As a solution to current problems, Qupas presents a review feature to share your experience using public services and products around you.</p>
				<div class="row">
					<div class="col-md">
						<img src="https://www.qupas.id/assets/layout/images/icon/category/food.png" class="img-fluid">
						<p class="text-center">Food</p>
					</div>
					<div class="col-md">
						<img src="https://www.qupas.id/assets/layout/images/icon/category/beauty.png" class="img-fluid">
						<p class="text-center">Beauty</p>
					</div>
					<div class="col-md">
						<img src="https://www.qupas.id/assets/layout/images/icon/category/leisure.png" class="img-fluid">
						<p class="text-center">Leisure</p>
					</div>
					<div class="col-md">
						<img src="https://www.qupas.id/assets/layout/images/icon/category/adventure.png" class="img-fluid">
						<p class="text-center">Adventure</p>
					</div>
				</div>
				<p>In addition to the review feature, Qupas also presents a renewal feature of Local Business information or Merchants that allows Merchants to be more informative to users. Besides, the filter features on Qupas offer advantages to Merchants to spread the latest promos and activities held by registered Merchants.

 

				The following are the full features contained in Qupas that you can use :</p>
			</section>
			<section id="">
				<h4><small><b>Complete Review</b></small></h4>
				<p>
					This feature allows Qupas users to provide reviews from merchants that have been visited, these reviews can be text or photos. The review feature combines the concept of Social Network Service (SNS) so that users can interact with other Qupas users such as giving comments, liking reviews and sharing reviews to the Timeline. On the other hand, registered Merchants can update the information on their Merchants and respond to reviews from users.</p>
			</section>
		</div>
	</div>
</div>