
<div class="container">	
	<div class="row mt-4">	
		<div class="col-md">
			<div class="bg-light shadow p-3">
				<h3 class="border-bottom pb-2">Panduan Untuk Penggunaan Public API</h3>
				<section id="content">
					<h3><small>	Download Panduan Untuk Penggunaan Public API</small></h3>
					<div class="container">	
						<div class="row">	
							<div class="col-md-1"></div>
							<div class="col-md-7">
								<p>	</p>
							</div>
						</div>
					</div>
				</section>
			</div>
		</div>
	</div>
</div>