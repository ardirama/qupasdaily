<style type="text/css">
	img	{
		border-radius: 3px;
	}
</style>
<div class="container">
	<div class="row mt-4">
		<div class="col-md-8">
			<h1 class="judul"><small><?= $content[0]['judul'] ?></small></h1>
			<p class="text-muted">Daily Qupas | <?= $content[0]['date'] ?> WIB | By Admin <span class="float-right">Tag : <a href="<?= base_url('category/detail/'.$content[0]['tag']) ?>" class="text-decoration-none text-success"><b><?= $content[0]['tag'] ?></b></a></span></p>
		</div>
	</div>
	<div class="row">
		<div class="col-md-9">
			<div class="bg-light shadow p-3">
				<img src="<?= base_url('gambar/'.$content[0]['gambar']) ?>" class="img-fluid mb-4">
				<?= $content[0]['content'] ?>
			</div>
		</div>
		<div class="col-md-3">
			<div class="bg-light shadow p-3 ">
				<h3 class="text-muted">Category :</h3>
				<p>
					<ol>
						<?php foreach ($kategori as $key) { ?>
							<a class="text-decoration-none" href="<?= base_url('category/detail/'.$key->kategori) ?>"><li><?= $key->kategori ?></li></a>
						<?php } ?>
					</ol>
				</p>
			</div>
		</div>
	</div>
</div>