<style type="text/css">
	.border-t{
		border-bottom: 3px solid #000;
	}
	.border-to:hover{
		border: none;
	}
</style>
<div class="container mt-5">
	<h2><span class="border-t border-to">Terbaru</span> <span class="float-right	 text-muted border-bottom"><small>Category : <?= $kategori ?></small></span></h2>
	<div class="row mt-4">
		<?php if ($kategori_m == null) { ?>
			<div class="col-md text-center">
				<h2 class="text-muted">Data Kategori <?= $kategori ?> Belum Tersedia</h2>
			</div>
		<?php }else{ ?>
		<?php foreach ($kategori_m as $key) { ?>
			
			<div class="col-md-4 mb-3">
				<img src="<?= base_url('gambar/'.$key->gambar) ?>" class="img-fluid rounded">
			</div>
			<a href="<?= base_url('category/content/'.$key->id) ?>" class="text-decoration-none text-muted">
			<div class="col-md-6 mb-3">
				<h3><?= $key->judul ?></h3>
				<p><a href="<?= base_url('category/detail/'.$key->tag) ?>" class="text-decoration-none"><?= $key->tag ?> </a><span class="ml-2 text-muted">| <?= $key->date ?> WIB</span></p>
			</div>
			</a>
		<?php } ?>
		<?php } ?>
	</div>
</div>