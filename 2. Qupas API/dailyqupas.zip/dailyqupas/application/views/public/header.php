<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <title><?= $judul ?></title>
  </head>
  <style type="text/css">
    .bot:hover{
      border-bottom: 3px solid black;
      border-radius: 2px;
    }
    .boti{
      border-bottom: 3px solid black;
    }
    body{
      font-family: 'Raleway', sans-serif;
    }
    .judul{
     font-family: 'Poppins', sans-serif;
    }
  </style>
  <body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow">
      <div class="container">
        <a class="navbar-brand" href="#"><img src="https://www.qupas.id/assets/layout/images/icon.png" class="img-fluid mr-2" width="50">Qupas Daily</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link bot" href="<?= base_url('') ?>">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link bot" href="<?= base_url('category/tags') ?>">Category</a>
            </li>
            <li class="nav-item">
              <a class="nav-link bot" href="<?= base_url('about') ?>">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link bot" href="<?= base_url('about/api') ?>">Public API</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
