<!-- content -->
    <div class="container mt-5">
      <div class="row mt-5">
        <div class="col-md">
          <div class="jumbotron jumbotron-fluid" style="width: 100%; background: url('https://www.qupas.id/assets/layout/images/background/april-2019/sidebar.jpg'); background-size: cover;">
            <div class="container text-center">
              <h1 class="display-3 ">Welcome To Daily Qupas</h1>
              <p class="lead"><a href="https://qupas.id" class="p-1 btn btn-secondary p-0 btn-sm"><img src="https://www.qupas.id/assets/layout/images/icon.png" width="20px" class="img-fluid"> Qupas</a><a href="" class="btn btn-dark btn-sm ml-3">Public API</a></p>
            </div>
          </div>
        </div>

        <div class="col-md-9">
          <div class="bg-light shadow p-3 rounded">
            <h2 class="mb-4 pl-3"><span class="border-bottom border-dark font-weight-bold">News</span></h2>
            <div class="row ml-1">
            <?php foreach ($isi as $key) { ?>
              <div class="col-md-4 mb-3 border-bottom pb-3">
                <img src="<?= base_url('gambar/'.$key->gambar) ?>" class="img-fluid rounded">
              </div>
              <a href="<?= base_url('category/content/'.$key->id) ?>" class="text-decoration-none text-muted">
              <div class="col-md-6 mb-3 border-bottom pb-3">
                <h3><?= $key->judul ?></h3>
                <p><a href="<?= base_url('category/detail/'.$key->tag) ?>" class="text-decoration-none"><?= $key->tag ?> </a><span class="ml-2 text-muted">| <?= $key->date ?> WIB</span></p>
              </div>
              </a>
            <?php } ?>
            </div>
          </div>
        </div>
        <div class="col-md-3">  
          <div class="bg-light shadow rounded p-3">
            <h3 class="text-muted">Category :</h3>
              <p>
                  <?php foreach ($kategori as $key) { ?>
                    <a class="text-decoration-none badge badge-outline-primary" href="<?= base_url('category/detail/'.$key->kategori) ?>"><?= $key->kategori ?></a>
                  <?php } ?>
              </p>
          </div>
        </div>
      </div>
    </div>
