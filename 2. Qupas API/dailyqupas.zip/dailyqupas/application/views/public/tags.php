<style type="text/css">
	.ko{
		box-shadow: 5px 10px linear-gradient(#3C3B3F,#605C3C);
	}
</style>
<div class="container">
	<div class="row">
		<div class="col-md mt-5">
			<h1 class="text-center"><small><span class="boti pb-2">All Categories</span></small></h1>	
		</div>
	</div>


	<div class="row mt-5">
<?php foreach ($tags as $key) { ?>
		<div class="col-md-3 mb-3">
			<a href="<?= base_url('category/detail/'.$key->kategori) ?>" class="text-decoration-none">
			<div class="card-group su">
			  <div class="card">
			    <img src="<?= base_url('gambar/'.$key->gambar) ?>" class="card-img-top img-fluid" alt="..." >
			    <div class="card-footer text-center">
			      <h5 class="text-dark"><small><?= $key->kategori ?></small></h5>
			 	</div>
			  </div>	
			</div>
			</a>
		</div>
<?php } ?>

	</div>

</div>
<script type="text/javascript">
	$(document).ready(function (){

		$('.su').hover(function(){
			$(this).addClass("shadow-lg");
		},function(){
			$( this ).removeClass("shadow-lg"); 
		});
	});
</script>